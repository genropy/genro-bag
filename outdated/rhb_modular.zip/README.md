
# RHB Documentation (Modular)

This ZIP contains modular RHB specification files:
- 01_structure.md
- 02_path_syntax.md
- 03_resolver.md
- 04_triggers.md
- 05_api_operations.md
