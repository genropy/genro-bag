
# RHB Specification — 05 API Operations

Bag:
- getitem(path, default)
- getNode(path)
- popNode(path)
- setItem(path, value, _attrs=None, **attrs)

Node:
- setValue(value, reason)
- setAttr(name, value, reason)
