
# BagNode — Node in the HLRS Tree

BagNode holds: label, attributes, value (possibly a nested Bag), parent_bag,
optional Resolver, and a node-local TriggerList.

(Details as previously defined.)
