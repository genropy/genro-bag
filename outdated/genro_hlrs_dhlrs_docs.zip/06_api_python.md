
# Python API Sketch

Illustrative Python API for Bag, BagNode, Resolver, TriggerList, following HLRS
semantics.

(Details as previously defined.)
