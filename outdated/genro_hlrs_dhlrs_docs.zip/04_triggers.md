
# Trigger System

Insert/delete/update events, node-local and Bag-level TriggerLists, propagation
upward with reason and level.

(Details as previously defined.)
