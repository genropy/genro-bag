
# JavaScript API Sketch

Illustrative JS API mirroring the Python semantics.

(Details as previously defined.)
