
# Bag — Core Hierarchical Structure

The Bag is the core container in Genro-HLRS. It stores an ordered mapping
from label → BagNode, plus attributes and a TriggerList for structural and
update events.

(Details as previously defined.)
