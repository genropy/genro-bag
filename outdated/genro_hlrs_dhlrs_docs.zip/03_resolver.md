
# Resolver — Lazy Evaluation

Resolvers compute node values on demand, sync or async, with caching and
integration into the trigger system.

(Details as previously defined.)
