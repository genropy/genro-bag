
# Path Syntax

Path grammar with segments: label, #N, /parent, ?attr. Safe navigation for
getitem and rules for setItem. 

(Details as previously defined.)
